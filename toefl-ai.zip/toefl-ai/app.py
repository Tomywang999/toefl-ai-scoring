from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from ai import edge
import asyncio

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mysecretkey'
socketio = SocketIO(app)

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('input_writing')
def handle_input(message, mode):
    tmp = ""
    if(mode=='inw'):
        tmp = asyncio.run(edge.toefl_writing_intergerted(message))
        emit('output', tmp)
    elif(mode=="disbw"):
        tmp = asyncio.run(edge.toefl_writing_discession(message))
        emit('output', tmp)
    elif(mode=="band30"):
        tmp = asyncio.run(edge.band30(message))
        emit('output', tmp)
    else:
        tmp = asyncio.run(edge.speaking(message))
        emit('output', tmp)


if __name__ == '__main__':
    socketio.run(app, debug=True, allow_unsafe_werkzeug=True)
