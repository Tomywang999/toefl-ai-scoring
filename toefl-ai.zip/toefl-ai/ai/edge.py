import json
from EdgeGPT import Chatbot, ConversationStyle
pwi = "Score this TOEFL integrated writing according to the official guide. Return a score between 1 and 5. And give comments based on the official guide. The return starts with the score, then by a comma, then with the comments. If you can not grade it just return “Unable Grading” "
pwd = "Score this TOEFL discussion board writing according to the official guide. Return a score between 1 and 5. And give comments based on the official guide. The return starts with the score, then by a comma, then following with the comments  If you can not grade it just return “Unable Grading” "
b30 = "Make this TOEFL writing a band30. Only return the rewritten text.  If you can not rewrite it just return “Unable rewrite” "
spk = "Make this TOEFL spekaing a band30. Only return the rewritten text. If you can not rewrite it just return “Unable rewrite” "
json_path = "cookie.json"

async def toefl_writing_intergerted(user_input):
    bot = await Chatbot.create(cookie_path=json_path)
    data = await bot.ask(prompt=pwi+user_input, conversation_style=ConversationStyle.creative,wss_link="wss://sydney.bing.com/sydney/ChatHub")
    await bot.close()
    string = data["item"]["messages"][1]["text"]
    with open("bot_return.txt", "w") as write_file:
        json.dump(string, write_file)
    return string

async def toefl_writing_discession(user_input):
    bot = await Chatbot.create(cookie_path=json_path)
    data = await bot.ask(prompt=pwd+user_input, conversation_style=ConversationStyle.creative,wss_link="wss://sydney.bing.com/sydney/ChatHub")
    await bot.close()
    string = data["item"]["messages"][1]["text"]
    with open("bot_return.txt", "w") as write_file:
        json.dump(string, write_file)
    return string

async def band30(user_input):
    bot = await Chatbot.create(cookie_path=json_path)
    data = await bot.ask(prompt=b30+user_input, conversation_style=ConversationStyle.creative,wss_link="wss://sydney.bing.com/sydney/ChatHub")
    await bot.close()
    string = data["item"]["messages"][1]["text"]
    with open("bot_return.txt", "w") as write_file:
        json.dump(string, write_file)
    return string

async def speaking(user_input):
    bot = await Chatbot.create(cookie_path=json_path)
    data = await bot.ask(prompt=spk+user_input, conversation_style=ConversationStyle.creative,wss_link="wss://sydney.bing.com/sydney/ChatHub")
    await bot.close()
    string = data["item"]["messages"][1]["text"]
    with open("bot_return.txt", "w") as write_file:
        json.dump(string, write_file)
    return string

