# TOEFL AI Scoring

This project is build based on [another project](https://github.com/acheong08/EdgeGPT) by @acheong08. This project include 4 tools for TOEFL Writing and speaking.

### Run this project
1. Get your microsoft cookie and put inside the file in ./ai/cookie.json
2. Run it
```
python3 app.py
```
